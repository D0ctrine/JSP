package controller;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.Dispatch;

import dao.ProductDAO;
import dto.memberADM;
import util.sessionAO;;
/**
 * Servlet implementation class login
 */
@WebServlet("/login.do")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		sessionAO session = sessionAO.getInstance();
		ProductDAO dao = ProductDAO.getInstance();
		String view = "login-register.jsp";
		if(request.getParameter("command")!=null) {
			String command = request.getParameter("command");
			if(command.equals("register")) {
				String sid =request.getParameter("sid");
				request.setAttribute("flag", dao.Signcheck(sid));
				request.setAttribute("id", sid);
				view="idchk.jsp";
			}else if(command.equals("clear")) {
				String sid =request.getParameter("sid");
				String sem =request.getParameter("sem");
				String spw =request.getParameter("spw1");
				String sname =request.getParameter("sname");
				String sphone =request.getParameter("sphone");
				String sregit =request.getParameter("sregit");
				memberADM member = new memberADM();
				member.setId(sid);
				member.setEmail(sem);
				member.setPw(spw);
				member.setSname(sname);
				member.setSphone(sphone);
				member.setSregit(sregit);
				dao.signinsert(member);
			}else if(command.equals("login")) {
				String uid =request.getParameter("Uid");
				String upw =request.getParameter("Upw");
				boolean[] flag = dao.login(uid, upw);
				if(flag[0]){
					memberADM m = new memberADM();
					m.setId(uid);
					if(flag[1]) {
					m.setAdmin("Y");	
					}
					session.setSession(m, request);
					view="main.do";
				}else {
					view = "errorchk.jsp?i=1";
				}
			}else if(command.equals("logout")) {
				session.exitSession(request);
			}
		}
		
		RequestDispatcher dispatcher = request
				.getRequestDispatcher(view);
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
