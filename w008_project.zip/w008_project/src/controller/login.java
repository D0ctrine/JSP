package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.Dispatch;

import dao.ProductDAO;
import dto.memberADM;;
/**
 * Servlet implementation class login
 */
@WebServlet("/login.do")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String commend = request.getParameter("commend");
		ProductDAO dao = ProductDAO.getInstance();
		String view = "login-register.jsp";
		if(commend==null) {
			commend="";
		}
		if(commend.equals("register")) {
		String sid =request.getParameter("sid");
		request.setAttribute("flag", dao.Signcheck(sid));
		request.setAttribute("id", sid);
		view="idchk.jsp";
		}else if(commend.equals("clear")) {
			String sid =request.getParameter("sid");
			String sem =request.getParameter("sem");
			String spw =request.getParameter("spw1");
			memberADM member = new memberADM();
			member.setId(sid);
			member.setEmail(sem);
			member.setPw(spw);
			dao.signinsert(member);
		}else if(commend.equals("login")) {
			String sid =request.getParameter("sid");
			String spw =request.getParameter("spw1");
			request.setAttribute("Uid", sid);
			request.setAttribute("Upw", spw);
			view="loginchk.jsp";
		}
		
		RequestDispatcher dispatcher = request
				.getRequestDispatcher(view);
		dispatcher.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
