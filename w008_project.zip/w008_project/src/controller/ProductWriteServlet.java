package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import dao.ProductDAO;
import dto.ProductVA;

/**
 * Servlet implementation class ProductWriteServlet
 */
@WebServlet("/productWrite.do")
public class ProductWriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductWriteServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("get");
		RequestDispatcher dispatcher = request
				.getRequestDispatcher("product/productWrite.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		/**
		 * ServletContext(�몴以� �뙆�씪 援ъ“): html, jsp, servlet �벑 媛곸쥌 resource�뿉 ���븳 �젙蹂대�� 媛�吏�怨� �엳�떎.
		 * �꽌釉붾┸ 而⑦뀒�씠�꼫�� �긽�샇�옉�슜�븯�뒗 �꽌釉붾┸�씠 �궗�슜�븯�뒗 set 硫붿냼�뱶�뱾�쓣 �젙�쓽�븳�떎. MIME ���엯�쓽 �뙆�씪�쓣 �뼸嫄곕굹 �씠�룞 �슂泥� �삉�뒗 濡쒓렇 �뙆�씪�쓣 �벐�뒗 湲곕뒫�쓣 �븳�떎.
			RequestDispatcher: forward, include瑜� �떆�궗�닔 �엳�뒗 �씤�꽣�럹�씠�뒪, �씠�룞�뿉 ���븳 �슂援ъ궗�빆�쓣 �떎�뻾�븳�떎.
		 */
		ServletContext context = getServletContext();
		String path = context.getRealPath("upload");
		System.out.println(path+" 파일 위치");
		String encType = "UTF-8";
		int sizeLimit = 20 * 1024 * 1024;
		MultipartRequest multi = new MultipartRequest(request, path, sizeLimit,
				encType, new DefaultFileRenamePolicy());
		String title = multi.getParameter("title");
		String contents = multi.getParameter("contents");
		String pictureUrl = multi.getFilesystemName("pictureUrl");
		System.out.println(title+"/"+contents+"/"+pictureUrl);
		if(pictureUrl == null) {
			System.out.println("url정보 없음");
		}else {
			System.out.println(pictureUrl+" ok");
		}
		ProductVA pVo = new ProductVA();
		pVo.setPicturl(pictureUrl);
		pVo.setContents(contents);
		pVo.setTitle(title);
		ProductDAO pDao = ProductDAO.getInstance();
		pDao.insertProduct(pVo);
		response.sendRedirect("productList.do");
	}

}
