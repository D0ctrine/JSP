package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ProductDAO;
import dto.memberADM;
import dto.productdto;

/**
 * Servlet implementation class main
 */
@WebServlet("/main.do")
public class main extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public main() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String view = "index.jsp";
		String param="command";
		ProductDAO dao = ProductDAO.getInstance();
		if(request.getParameter(param)!=null) {
			String command = request.getParameter(param);
			if(command.equals("update")) {
				String name = request.getParameter("na");
				String email = request.getParameter("em");
				String number = request.getParameter("pn");
				String re = request.getParameter("re");
				String id = request.getParameter("id");
				memberADM m = new memberADM();
				m.setSname(name);
				m.setEmail(email);
				m.setSphone(number);
				m.setSregit(re);
				m.setId(id);
				dao.updatemember(m);
			}else if(command.equals("remove")) {
				String id = request.getParameter("id");
				dao.removemember(id);
				view="login.do?command=logout";
			}else if(command.equals("itemremove")) {
				int scode = Integer.parseInt(request.getParameter("scode"));
				dao.removeproduct(scode);
				command="mypage";
			}else if(command.equals("consume")) {
				view="consume.jsp";
			}
			
			if(command.equals("mypage")) {
				HttpSession session = request.getSession();
				String id = session.getAttribute("id").toString();
				memberADM m = dao.getMyInfo(id);
				request.setAttribute("box", m);
				List<productdto> dto = dao.productList(id);
				request.setAttribute("list", dto);
				view = "single-portfolio.jsp";
			}
		}
		RequestDispatcher dispatcher = request
				.getRequestDispatcher(view);		
		dispatcher.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
