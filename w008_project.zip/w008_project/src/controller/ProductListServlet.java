package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ProductDAO;
import dto.ProductVA;
import dto.commentV;

/**
 * Servlet implementation class ProductListServlet
 */
@WebServlet("/productList.do")
public class ProductListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductListServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	List<ProductVA> productList=null;
	int page=1;
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		ProductDAO pDao = ProductDAO.getInstance();
		productList = pDao.selectAllProducts();
		
//		List<commentV> cv = pDao.selectcomment();
		List<ProductVA> cd = new ArrayList<ProductVA>();
		if(request.getParameter("page")==null) {
			
				for(int i=0;i<5;i++) {
					cd.add(productList.get(i));			
				}
			
			request.setAttribute("productList", cd);
		}else{
			
			page = Integer.parseInt(request.getParameter("page"));
			if(page<1) {
				page=1;
			}
			if(productList.size()>(page*5)) {
				for(int i=(page*5-5);i<page*5;i++) {
					cd.add(productList.get(i));			
				}
			}else {
				for(int i=(page*5-5);i<productList.size();i++) {
					cd.add(productList.get(i));			
				}	
			}
			request.setAttribute("productList", cd);
		}
//		request.setAttribute("cv", cv);
		request.setAttribute("page", page);
			
	
		RequestDispatcher dispatcher = request
				.getRequestDispatcher("product/productList.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
