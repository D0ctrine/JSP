package dto;

import java.sql.Date;

public class wishdto {
private int code;
private String sid;
private Date day;
private String stype;
public int getCode() {
	return code;
}
public void setCode(int code) {
	this.code = code;
}
public String getSid() {
	return sid;
}
public void setSid(String sid) {
	this.sid = sid;
}
public Date getDay() {
	return day;
}
public void setDay(Date day) {
	this.day = day;
}
public String getStype() {
	return stype;
}
public void setStype(String stype) {
	this.stype = stype;
}
}
