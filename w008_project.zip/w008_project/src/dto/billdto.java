package dto;

import java.sql.Timestamp;

public class billdto {
private String bcode;
private int total;
private Timestamp time;
private String ip;
private String sid;
public String getBcode() {
	return bcode;
}
public void setBcode(String bcode) {
	this.bcode = bcode;
}
public int getTotal() {
	return total;
}
public void setTotal(int total) {
	this.total = total;
}
public Timestamp getTime() {
	return time;
}
public void setTime(Timestamp time) {
	this.time = time;
}
public String getIp() {
	return ip;
}
public void setIp(String ip) {
	this.ip = ip;
}
public String getSid() {
	return sid;
}
public void setSid(String sid) {
	this.sid = sid;
}
}
