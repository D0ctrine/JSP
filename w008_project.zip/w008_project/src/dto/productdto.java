package dto;

public class productdto {
private String sid;
private String sname;
private String stype;
private String path;
private int price;
private int cnt;
private int scode;
public int getScode() {
	return scode;
}
public void setScode(int scode) {
	this.scode = scode;
}
private int discount;
public int getCnt() {
	return cnt;
}
public void setCnt(int cnt) {
	this.cnt = cnt;
}
public int getDiscount() {
	return discount;
}
public void setDiscount(int discount) {
	this.discount = discount;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public String getPath() {
	return path;
}
public void setPath(String path) {
	this.path = path;
}
public String getSid() {
	return sid;
}
public void setSid(String sid) {
	this.sid = sid;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public String getStype() {
	return stype;
}
public void setStype(String stype) {
	this.stype = stype;
}
}
