package dto;

public class ProductVA {
private String dates;
private String title;
private String contents;
private String picturl;
public String getDates() {
	return dates;
}
public void setDates(String dates) {
	this.dates = dates;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getContents() {
	return contents;
}
public void setContents(String contents) {
	this.contents = contents;
}
public String getPicturl() {
	return picturl;
}
public void setPicturl(String picturl) {
	this.picturl = picturl;
}
}
