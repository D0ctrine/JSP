package dto;

public class memberADM {
private String id;
private String pw;
private String email;
private String sname;
private String sphone;
private String sregit;
private String date;
private String admin;
public String getAdmin() {
	return admin;
}
public void setAdmin(String admin) {
	this.admin = admin;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public String getSphone() {
	return sphone;
}
public void setSphone(String sphone) {
	this.sphone = sphone;
}
public String getSregit() {
	return sregit;
}
public void setSregit(String sregit) {
	this.sregit = sregit;
}
private String point;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getPw() {
	return pw;
}
public void setPw(String pw) {
	this.pw = pw;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPoint() {
	return point;
}
public void setPoint(String point) {
	this.point = point;
}
}
