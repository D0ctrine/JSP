package dto;

public class patterndto {
private String stype;
public String getStype() {
	return stype;
}
public void setStype(String stype) {
	this.stype = stype;
}
private int cnt;
public int getCnt() {
	return cnt;
}
public void setCnt(int cnt) {
	this.cnt = cnt;
}
}
