package dto;
public class PageNumber {
	private int page;  
	private int count; 
	private int start; 
	private int end;   
	private int nowPageStart; 
	private int nowPageEnd;
	private int prev;
	private int next;

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		if (page < 1) {
			this.page = 1;
			return;
		}
		this.page = page;
	}

	public void setCount(Integer count) {
		if (count < 1) {
			return;
		}
		this.count = count;
		calcPage();
	}

	public int getCount() {
		return count;
	}

	public int getStart() {
		return start;
	}

	public int getEnd() {
		return end;
	}

	public int getPrev() {
		return prev;
	}

	public int getNext() {
		return next;
	}

	public int getNowPageStart() {
		return nowPageStart;
	}

	public int getNowPageEnd() {
		return nowPageEnd;
	}

	private void calcPage() {
		int tempEnd = (int) (Math.ceil(page / 8.0) * 8); 

		this.start = tempEnd - 7;
		if (tempEnd * 10 > this.count) {
			this.end = (int) Math.ceil(this.count / 8.0);
		} else {
			this.end = tempEnd;
		}
		
		nowPageStart = (page-1)*8+1;
		nowPageEnd = nowPageStart + 7;
		if(nowPageEnd > this.count) {
			nowPageEnd=this.count;
		}
		
//		System.out.println("page = " + page);
//		System.out.println("start = " + start);
//		System.out.println("this.end = " + this.end);
//		System.out.println("nowpageStart= " + this.nowPageStart);
//		System.out.println("nowpageEnd= " + this.nowPageEnd);
		//this.prev = this.start != 1;
	//	this.next = this.end * 10 < this.count;
	}
}
