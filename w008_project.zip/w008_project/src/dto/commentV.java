package dto;

public class commentV {
private String comment;
private String title;
public String getComment() {
	return comment;
}
public void setComment(String comment) {
	this.comment = comment;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
}
