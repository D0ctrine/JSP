package dto;

import java.sql.Timestamp;

public class commentV {
private String comment;
private String id;
private int ccode;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
private int star;
private int fcode;
private Timestamp day;
public int getStar() {
	return star;
}
public int getFcode() {
	return fcode;
}
public void setFcode(int fcode) {
	this.fcode = fcode;
}
public Timestamp getDay() {
	return day;
}
public void setDay(Timestamp day) {
	this.day = day;
}
public void setStar(int star) {
	this.star = star;
}
public String getComment() {
	return comment;
}
public void setComment(String comment) {
	this.comment = comment;
}
public int getCcode() {
	return ccode;
}
public void setCcode(int ccode) {
	this.ccode = ccode;
}
}
