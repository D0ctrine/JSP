package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import dto.billdto;
import dto.cartdto;
import dto.memberADM;
import dto.productdto;
import util.DBManager;

public class ProductDAO {
	private ProductDAO() {
	}

	private static ProductDAO instance = new ProductDAO();

	public static ProductDAO getInstance() {
		return instance;
	}
public void signinsert(memberADM m) {
	String sql = "insert into human values(?,?,?,default,?,?,?,sysdate,0,default)";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m.getId());
			pstmt.setString(2, m.getPw());
			pstmt.setString(3, m.getEmail());
			pstmt.setString(4, m.getSname());
			pstmt.setString(5, m.getSphone());
			pstmt.setString(6, m.getSregit());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
public boolean[] login(String id,String pw) {
	boolean[] flag = new boolean[2];
	String sql = "select * from human where mid=? and mpw=?";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				String k=rs.getString("mid");
				String admin=rs.getString("admin");
				if(k!=null) {
					flag[0]=true;
				}
				if(admin.equals("Y")) {
					flag[1]=true;
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return flag;
	
}
public int Signcheck(String id) {
	int flag = 0;
	String sql = "select * from human where mid=?";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			flag= pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return flag;
}
public memberADM getMyInfo(String id) {
	 memberADM m = new memberADM();
	String sql = "select * from human where mid=?";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			 if(rs.next()) {
				 m.setEmail(rs.getString("email"));
				 m.setSname(rs.getString("sname"));
				 m.setSphone(rs.getString("sphone"));
				 m.setSregit(rs.getString("sregit"));
				 m.setDate(rs.getString("day"));
			 }
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt,rs);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return m;
}
public void productInsert(productdto p) {
	String sql = "insert into shop values(?,?,?,scode_seq.nextVal,?,sysdate,?,?,?)";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, p.getSid());
			pstmt.setString(2, p.getSname());
			pstmt.setString(3, p.getStype());
			pstmt.setString(4, p.getPath());
			pstmt.setInt(5, p.getPrice());
			pstmt.setInt(6, p.getCnt());
			pstmt.setInt(7, p.getDiscount());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

public void updatemember(memberADM m) {
	String sql = "update human set sname=? , sphone=?,sregit=?,email=? where mid=?";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m.getSname());
			pstmt.setString(2, m.getSphone());
			pstmt.setString(3, m.getSregit());
			pstmt.setString(4, m.getEmail());
			pstmt.setString(5, m.getId());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}
public void removemember(String id) {
	String sql = "delete human where mid=?";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
public List<productdto> productList() {
	List<productdto> box = new ArrayList<productdto>();
	String sql = "select * from shop order by day desc";
	try {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs= pstmt.executeQuery();
			while(rs.next()) {
				productdto dto = new productdto();
				dto.setSid(rs.getString("sid"));
				dto.setSname(rs.getString("sname"));
				dto.setScode(rs.getInt("scode"));
				dto.setPath(rs.getString("path"));
				dto.setPrice(rs.getInt("sprice"));
				dto.setDiscount(rs.getInt("discount"));
				box.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt,rs);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	return box;
}
public void removeproduct(int code) {
	String sql = "delete shop where scode=?";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, code);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
public List<productdto> productList(String id) {
	String sql = "select * from shop where sid=?";
	List<productdto> box = new ArrayList<productdto>();
	try {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs= pstmt.executeQuery();
			while(rs.next()) {
				productdto dto = new productdto();
				dto.setSname(rs.getString("sname"));
				dto.setStype(rs.getString("stype"));
				dto.setPath(rs.getString("path"));
				dto.setPrice(rs.getInt("sprice"));
				dto.setScode(rs.getInt("scode"));
				box.add(dto);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt,rs);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	return box;
}
public productdto getList(int code) {
	productdto dto = new productdto();
	String sql = "select * from shop where scode=?";
	try {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, code);
			rs= pstmt.executeQuery();
			if(rs.next()) {
				dto.setSid(rs.getString("sid"));
				dto.setSname(rs.getString("sname"));
				dto.setStype(rs.getString("stype"));
				dto.setPrice(rs.getInt("sprice"));
				dto.setPath(rs.getString("path"));
				dto.setScode(rs.getInt("scode"));
				dto.setCnt(rs.getInt("cnt"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt,rs);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return dto;
}	

//CartLine DAO 장바구니
public void cartInsert(cartdto c) {
	String sql = "insert into cart values(?,?,?,sysdate,default,cart_seq.nextval)";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, c.getCode());
			pstmt.setString(2, c.getSid());
			pstmt.setInt(3, c.getCnt());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
public List<cartdto> cartList(String id) {
	List<cartdto> box = new ArrayList<cartdto>();
	String sql = "select * from cart where sid=?";
	try {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs= pstmt.executeQuery();
			while(rs.next()) {
				cartdto dto = new cartdto();
				int code=rs.getInt("code");
				dto.setCode(code);
				productdto list= getList(code);
				dto.setStype(list.getStype());
				dto.setPath(list.getPath());
				dto.setDay(rs.getDate("day")+"");
				dto.setName(list.getSname());
				dto.setCnt(list.getCnt());
				dto.setPrice(list.getPrice());
				box.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt,rs);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	return box;
}
public void removecartitem(int c,String id) {
	String sql = "delete cart where code=? and sid=?";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, c);
			pstmt.setString(2, id);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
public void buycart(String id) {
	String sql = "update cart set buy='Y' where sid=? and buy='N'";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
public String namecart(String id) {
	String sql = "select code from cart where sid=? and buy='N'";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			id="";
			while(rs.next()) {
				id+=rs.getString("code")+"/";
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt,rs);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	return id;
	
}
//bill line
public boolean billInsert(billdto b) {
	String sql = "insert into bill values(?,?,systimestamp,?,?)";
	boolean flag=false;
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, b.getBcode());
			pstmt.setInt(2, b.getTotal());
			pstmt.setString(3, b.getIp());
			pstmt.setString(4, b.getSid());
			pstmt.executeUpdate();
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return flag;
}

}
