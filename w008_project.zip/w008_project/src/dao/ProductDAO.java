package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import dto.ProductVA;
import dto.ProductVO;
import dto.commentV;
import dto.memberADM;
import util.DBManager;

public class ProductDAO {
	private ProductDAO() {
	}

	private static ProductDAO instance = new ProductDAO();

	public static ProductDAO getInstance() {
		return instance;
	}
public void signinsert(memberADM m) {
	String sql = "insert into human values(?,?,?,default)";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m.getId());
			pstmt.setString(2, m.getPw());
			pstmt.setString(3, m.getEmail());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
public boolean login(String id,String pw) {
	boolean flag = false;
	String sql = "select * from human where mid=? and mpw=?";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				String k=rs.getString("mid");
				if(k!=null) {
					flag=true;
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return flag;
	
}
public boolean Signcheck(String id) {
	boolean flag = false;
	String sql = "select * from human where mid=?";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				String k=rs.getString("mid");
				if(k==null) {
					flag=true;
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return flag;
}
	// c Read u d
	public List<ProductVA> selectAllProducts() {
		List<ProductVA> list = new ArrayList<ProductVA>();
		// 筌ㅼ뮄�젏 占쎈쾻嚥≪빜釉� 占쎄맒占쎈�� �솒�눘占� �빊�뮆�젾占쎈릭疫뀐옙
		String sql = "select * from gesipan order by dates asc";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) { // 占쎌뵠占쎈짗占쏙옙 占쎈뻬(嚥≪뮇�뒭) 占쎈뼊占쎌맄嚥∽옙
				ProductVA pVo = new ProductVA();
				pVo.setDates(rs.getString("dates"));
				pVo.setPicturl(rs.getString("picturl"));
				pVo.setTitle(rs.getString("title"));
				pVo.setContents(rs.getString("contents"));
				list.add(pVo);
			}// while�눧占� 占쎄국
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		return list;
	}// selectAllProducts() {

	public void insertProduct(ProductVA pVo) {
		String sql = "insert into gesipan values(?, ?, ?, ?)";
		Connection conn = null;
		PreparedStatement pstmt = null;
		Date time = new Date();
		SimpleDateFormat time1 = new SimpleDateFormat("hh:mm:ss a");
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, time1.format(time));
			pstmt.setString(2, pVo.getTitle());
			pstmt.setString(3, pVo.getContents());
			pstmt.setString(4, pVo.getPicturl());
			pstmt.executeUpdate(); // 占쎈뼄占쎈뻬
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}

	public ProductVA selectProductByCode(String code) {
		String sql = "select * from gesipan where dates=?";
		ProductVA pVo = null;
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, code);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					pVo = new ProductVA();
					pVo.setTitle(rs.getString("name"));
					pVo.setDates(rs.getString("dates"));
					pVo.setPicturl(rs.getString("pictureUrl"));
					pVo.setContents(rs.getString("description"));
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt, rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pVo;
	}

	public void updateProduct(ProductVO pVo) {
		String sql = "update product set name=?, price=?, pictureurl=?, description=? where code=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, pVo.getName());
			pstmt.setInt(2, pVo.getPrice());
			pstmt.setString(3, pVo.getPictureUrl());
			pstmt.setString(4, pVo.getDescription());
			pstmt.setInt(5, pVo.getCode());
			pstmt.executeUpdate();// �뜎�눖�봺�눧占� 占쎈뼄占쎈뻬占쎈립占쎈뼄.
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}
	public void updategesipan(ProductVA pVo,String title) {
		String sql = "update product set dates=?, title=?, contents=?, picturl=? where title=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		Date time = new Date();
		SimpleDateFormat time1 = new SimpleDateFormat("hh:mm:ss a");
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, time1.format(time));
			pstmt.setString(2, pVo.getTitle());
			pstmt.setString(3, pVo.getContents());
			pstmt.setString(4, pVo.getPicturl());
			pstmt.setString(5, title);
			pstmt.executeUpdate();// �뜎�눖�봺�눧占� 占쎈뼄占쎈뻬占쎈립占쎈뼄.
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}
	public void deleteProduct(String code) {
		String sql = "delete gesipan where title=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		System.out.println(code+"/ delete?");
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, code);
			pstmt.executeUpdate();// �뜎�눖�봺�눧占� 占쎈뼄占쎈뻬
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}
	
}
