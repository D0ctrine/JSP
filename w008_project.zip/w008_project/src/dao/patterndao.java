package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import dto.patterndto;
import dto.wishdto;
import util.DBManager;

public class patterndao {
	private patterndao() {
	}

	private static patterndao instance = new patterndao();

	public static patterndao getInstance() {
		return instance;
	}
	
	public int[] getMyInfo(String id) {
		int pbox[] = new int[3];
		String sql = "select s.stype type, sum(c.cnt) cnt from shop s right outer join (select * from cart where sid=?) c on s.scode=c.code group by s.stype";
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
				rs = pstmt.executeQuery();
				 while(rs.next()) {
					 if(rs.getString("type").equals("clothes")) {
						 pbox[0] = rs.getInt("cnt");
					 }else if(rs.getString("type").equals("pants")) {
						 pbox[1] = rs.getInt("cnt");
					 }else {
						 pbox[2] = rs.getInt("cnt");
					 }
					 
				 }
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt,rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pbox;
	}
	
	//wish �Ѱ��߿� �Ȼ��
	public ArrayList<Integer> getMyWish(String id) {
		ArrayList<Integer> pbox = new ArrayList<Integer>();
		String sql = "select w.code code from wish w right outer join (select * from cart where sid=? and buy='n') c on w.code=c.code";
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
				rs = pstmt.executeQuery();
				while(rs.next()) {
					 pbox.add(rs.getInt("code"));
				 }
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt,rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pbox;
	}
	
	//wish �Ѱ��߿� ��͵�
	public ArrayList<Integer> getWishbuy(String id) {
		ArrayList<Integer> pbox = new ArrayList<Integer>();
		String sql = "select w.code code from wish w right outer join (select * from cart where sid=? and buy='Y') c on w.code=c.code";
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
				rs = pstmt.executeQuery();
				 while(rs.next()) {
					 pbox.add(rs.getInt("code"));
				 }
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt,rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pbox;
	}
	//horder
	public void setorder(int i,String id) {
		String sql="update human set horder=? and mid=?";
		
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, i);
				pstmt.setString(2, id);
				pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public String checkwish(int code) {
		String sql = "select stype from shop where scode=?";
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, code);
				rs = pstmt.executeQuery();
				 if(rs.next()) {
					sql =(rs.getString("stype"));
				 }
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt,rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sql;
	}
	
}
