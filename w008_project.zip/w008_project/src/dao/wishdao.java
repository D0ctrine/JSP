package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import dto.memberADM;
import dto.wishdto;
import util.DBManager;

public class wishdao {
	private wishdao() {
	}

	private static wishdao instance = new wishdao();

	public static wishdao getInstance() {
		return instance;
	}
	
	public memberADM getMyInfo(String id) {
		 memberADM m = new memberADM();
		String sql = "select * from human where mid=?";
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
				rs = pstmt.executeQuery();
				 if(rs.next()) {
					 m.setEmail(rs.getString("email"));
					 m.setSname(rs.getString("sname"));
					 m.setSphone(rs.getString("sphone"));
					 m.setSregit(rs.getString("sregit"));
					 m.setDate(rs.getString("day"));
				 }
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt,rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return m;
	}
	public void wishInsert(wishdto w) {
		String sql = "insert into wish values(?,?,sysdate,?)";
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, w.getCode());
				pstmt.setString(2, w.getSid());
				pstmt.setString(3, w.getStype());
				
				pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public List<wishdto> getwish(String id) {
		if(id==null) {
			return null;
		}
		List<wishdto> box = new ArrayList<wishdto>();
		String sql = "select * from wish where sid=?";
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
				rs = pstmt.executeQuery();
				 while(rs.next()) {
					 wishdto w = new wishdto();
					 w.setCode(rs.getInt("code"));
					 w.setDay(rs.getDate("day"));
					 w.setStype(rs.getString("stype"));
					 box.add(w);
				 }
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt,rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return box;
	}

}
