package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import dto.commentV;
import dto.memberADM;
import dto.wishdto;
import util.DBManager;

public class commentdao {
	private commentdao() {
	}

	private static commentdao instance = new commentdao();

	public static commentdao getInstance() {
		return instance;
	}
	
	public List<commentV> getComments(int fcode) {
		List<commentV> m = new ArrayList<commentV>();
		String sql = "select * from comments where fcode=? order by day desc";
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, fcode);
				rs = pstmt.executeQuery();
				 if(rs.next()) {
					 commentV c = new commentV();
					c.setComment(rs.getString("comments"));
					c.setDay(rs.getTimestamp("day"));
					c.setFcode(rs.getInt("fcode"));
					c.setStar(rs.getInt("star"));
					c.setCcode(rs.getInt("ccode"));
					c.setId(rs.getString("id"));
					m.add(c);
				 }
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt,rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return m;
	}
	public void commentsInsert(commentV c) {
		String sql = "insert into comments values(?,comment_seq.nextval,?,systimestamp,?,?)";
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, c.getFcode());
				pstmt.setInt(2, c.getStar());
				pstmt.setString(3, c.getId());
				pstmt.setString(4, c.getComment());
				pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public void delcomments(int c) {
		String sql = "delete comments where ccode=?";
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, c);
				pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public boolean Checkcomments(String id,int fcode) {
		String sql = "select * from comments where id=? and fcode=?";
		boolean flag=true;
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(2, fcode);
				pstmt.setString(1, id);
				int k=pstmt.executeUpdate();
				if(k!=0) {
					flag = false;
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}


}
