package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.eclipse.jdt.internal.compiler.ast.ArrayAllocationExpression;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import dao.ProductDAO;
import dto.billdto;
import dto.cartdto;
import dto.productdto;

/**
 * Servlet implementation class shop
 */
@WebServlet("/shop.do")
public class shop extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public shop() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("utf-8");
		ProductDAO dao = ProductDAO.getInstance();
		String view = "shop.jsp";
		String param="command";
		if(request.getParameter(param)!=null) {
			String command = request.getParameter(param);
			if(command.equals("gesi")) {
				view="gesi.jsp";
			}else if(command.equals("clear")) {
				ServletContext context = getServletContext();
				String path = context.getRealPath("upload");
				String encType ="utf-8";
				int sizeLimit = 20*1024*1024;
				MultipartRequest multi = new MultipartRequest(request, path,sizeLimit,encType,new DefaultFileRenamePolicy());
				String id =multi.getParameter("id");
				String name = multi.getParameter("name");
				String type = multi.getParameter("type");
				int price = Integer.parseInt(multi.getParameter("price"));
				String url = multi.getFilesystemName("pictureUrl");
				int count = Integer.parseInt(multi.getParameter("cnt"));
				int discount = Integer.parseInt(multi.getParameter("discount"));
				productdto p = new productdto();
				p.setSid(id);
				p.setPrice(price);
				p.setPath(url);
				p.setSname(name);
				p.setStype(type);
				p.setCnt(count);
				p.setDiscount(discount);
				dao.productInsert(p);
				view="errorchk.jsp?i=5";
			}else if(command.equals("detail")) {
				view="product-details.jsp";
				int scode =Integer.parseInt(request.getParameter("dcode"));
				productdto dto = dao.getList(scode);
				request.setAttribute("box", dto);
			}else if(command.equals("cart")) {
				int scode =Integer.parseInt(request.getParameter("code"));
				request.setAttribute("code", scode);
				view="errorchk.jsp?i=6";
			}else if(command.equals("cartlist")) {
				HttpSession session =request.getSession();
				String id = session.getAttribute("id").toString();
				List<cartdto> box =dao.cartList(id);
				int sum=0;
				for(int i=0;i<box.size();i++) {
					sum+=box.get(i).getPrice();
				}
				request.setAttribute("sum", sum);
				request.setAttribute("box", box);
				view="cart.jsp";
			}else if(command.equals("cartremove")) {
				int code = Integer.parseInt(request.getParameter("code"));
				HttpSession session =request.getSession();
				String id = session.getAttribute("id").toString();
				dao.removecartitem(code, id);
				List<cartdto> box =dao.cartList(id);
				request.setAttribute("box", box);
				view="cart.jsp";
			}else if(command.equals("checkout")) {
					int total = Integer.parseInt(request.getParameter("total"));
					billdto b = new billdto();
					b.setTotal(total);
					b.setIp(request.getRemoteAddr());
					HttpSession session =request.getSession();
					String id = session.getAttribute("id").toString();
					b.setSid(id);
					b.setBcode(dao.namecart(id));
					if(dao.billInsert(b)) { //���� �Ϸ�
					dao.buycart(id);
					view="errorchk.jsp?i==2";
					}else { //���� ���
						view="errorchk.jsp?i==3";
					}
			}else if(command.equals("cart1")) {
				int scode=Integer.parseInt(request.getParameter("code"));
				HttpSession session =request.getSession();
				String id = session.getAttribute("id").toString();
				cartdto c = new cartdto();
				c.setCode(scode);
				c.setSid(id);
				dao.cartInsert(c);
				List<productdto> box =dao.productList();
				request.setAttribute("box", box);
				//�ڲ� 2�� ���� īƮ�� ��
			}
			
		}else {
			List<productdto> box =dao.productList();
			ArrayList<Integer> list = new ArrayList<Integer>(); 
			for(int i=0;i<box.size();i++) {
					list.add(box.get(i).getPrice()*(100-box.get(i).getDiscount())/100);
			}
			request.setAttribute("list", list);
			request.setAttribute("box", box);
		}
		
		
		
		RequestDispatcher dispatcher = request
				.getRequestDispatcher(view);
		dispatcher.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
