package util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import dto.memberADM;

public class sessionAO {
	private sessionAO() {
	}

	private static sessionAO instance = new sessionAO();

	public static sessionAO getInstance() {
		return instance;
	}
	
	public void setSession(memberADM m,HttpServletRequest request) {
		HttpSession session = request.getSession(true);
		session.setAttribute("id", m.getId());
	}
	
	public void exitSession(HttpServletRequest request) {
		HttpSession session = request.getSession(true);
		session.invalidate();
	}
	
	
}
