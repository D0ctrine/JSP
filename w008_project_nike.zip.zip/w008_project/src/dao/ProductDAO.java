package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import dto.commentV;
import dto.memberADM;
import dto.productdto;
import util.DBManager;

public class ProductDAO {
	private ProductDAO() {
	}

	private static ProductDAO instance = new ProductDAO();

	public static ProductDAO getInstance() {
		return instance;
	}
public void signinsert(memberADM m) {
	String sql = "insert into human values(?,?,?,default,?,?,?)";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m.getId());
			pstmt.setString(2, m.getPw());
			pstmt.setString(3, m.getEmail());
			pstmt.setString(4, m.getSname());
			pstmt.setString(5, m.getSphone());
			pstmt.setString(6, m.getSregit());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
public boolean login(String id,String pw) {
	boolean flag = false;
	String sql = "select * from human where mid=? and mpw=?";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				String k=rs.getString("mid");
				if(k!=null) {
					flag=true;
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return flag;
	
}
public int Signcheck(String id) {
	int flag = 0;
	String sql = "select * from human where mid=?";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			flag= pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return flag;
}
public memberADM getMyInfo(String id) {
	 memberADM m = new memberADM();
	String sql = "select * from human where mid=?";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			 if(rs.next()) {
				
				 m.setEmail(rs.getString("email"));
				 m.setSname(rs.getString("sname"));
				 m.setSphone(rs.getString("sphone"));
				 m.setSregit(rs.getString("sregit"));
			
			 }
			 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt,rs);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return m;
}
public void productInsert(productdto p) {
	String sql = "insert into shop values(?,?,?,scode_seq.nextVal,?,?)";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, p.getSid());
			pstmt.setString(2, p.getSname());
			pstmt.setString(3, p.getStype());
			pstmt.setString(4, p.getPath());
			pstmt.setString(5, p.getPrice()+"");
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
public void updatemember(memberADM m) {
	String sql = "update human set sname=? , sphone=?,sregit=?,email=? where mid=?";
	try {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m.getSname());
			pstmt.setString(2, m.getSphone());
			pstmt.setString(3, m.getSregit());
			pstmt.setString(4, m.getEmail());
			pstmt.setString(5, m.getId());
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
public List<productdto> productList() {
	List<productdto> box = new ArrayList<productdto>();
	String sql = "select * from shop";
	try {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs= pstmt.executeQuery();
			while(rs.next()) {
				productdto dto = new productdto();
				dto.setSid(rs.getString("sid"));
				dto.setSname(rs.getString("sname"));
				dto.setStype(rs.getString("scode"));
				dto.setPath(rs.getString("path"));
				dto.setPrice(rs.getString("price"));
				box.add(dto);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt,rs);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	return box;
}
public List<productdto> productList(String id) {
	String sql = "select * from shop where sid=?";
	List<productdto> box = new ArrayList<productdto>();
	try {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs= pstmt.executeQuery();
			while(rs.next()) {
				productdto dto = new productdto();
				dto.setSname(rs.getString("sname"));
				dto.setStype(rs.getString("stype"));
				dto.setPath(rs.getString("path"));
				dto.setPrice(rs.getString("price"));
				box.add(dto);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt,rs);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	return box;
}
	
}
