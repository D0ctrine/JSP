package dto;

public class productdto {
private String sid;
private String sname;
private String stype;
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
private String path;
private String price;
public String getPath() {
	return path;
}
public void setPath(String path) {
	this.path = path;
}
public String getSid() {
	return sid;
}
public void setSid(String sid) {
	this.sid = sid;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public String getStype() {
	return stype;
}
public void setStype(String stype) {
	this.stype = stype;
}
}
