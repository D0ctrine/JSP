package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import dao.ProductDAO;
import dto.productdto;
import util.sessionAO;

/**
 * Servlet implementation class shop
 */
@WebServlet("/shop.do")
public class shop extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public shop() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("utf-8");
		ProductDAO dao = ProductDAO.getInstance();
		String view = "shop.jsp";
		String param="command";
		if(request.getParameter(param)!=null) {
			String command = request.getParameter(param);
			if(command.equals("gesi")) {
				view="gesi.jsp";
			}else if(command.equals("clear")) {
				ServletContext context = getServletContext();
				String path = context.getRealPath("upload");
				String encType ="utf-8";
				int sizeLimit = 20*1024*1024;
				MultipartRequest multi = new MultipartRequest(request, path,sizeLimit,encType,new DefaultFileRenamePolicy());
				String id =multi.getParameter("id");
				String name = multi.getParameter("name");
				String type = multi.getParameter("type");
				String price = multi.getParameter("price");
				String url = multi.getFilesystemName("pictureUrl");
				productdto p = new productdto();
				p.setSid(id);
				p.setPrice(price);
				p.setPath(url);
				p.setSname(name);
				p.setStype(type);
				dao.productInsert(p);
			}
		}else {
			List<productdto> box =dao.productList();
			request.setAttribute("box", box);
		}
		
		
		
		RequestDispatcher dispatcher = request
				.getRequestDispatcher(view);
		dispatcher.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
